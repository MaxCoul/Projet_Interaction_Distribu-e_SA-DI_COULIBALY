import cv2
import requests
import numpy as np
import matplotlib.pyplot as plt

def display_mjpeg_stream(url):
    """
    Lit et affiche un flux MJPEG en extrayant des frames depuis le flux HTTP.
    """
    # Ouvrir le flux HTTP en mode stream
    response = requests.get(url, stream=True)
    if response.status_code != 200:
        raise ValueError(f"Impossible d'accéder au flux vidéo : {url}")

    byte_data = b""
    try:
        for chunk in response.iter_content(chunk_size=1024):
            byte_data += chunk
            print("Chunk brut reçu :", chunk[:100])
            # Trouver les délimitations JPEG
            start = byte_data.find(b'\xff\xd8')  # Début JPEG
            end = byte_data.find(b'\xff\xd9')  # Fin JPEG

            if start != -1 and end != -1:
                # Extraire et décoder l'image JPEG
                jpg = byte_data[start:end+2]
                byte_data = byte_data[end+2:]
                frame = cv2.imdecode(np.frombuffer(jpg, dtype=np.uint8), cv2.IMREAD_COLOR)

                if frame is not None:
                    # Afficher la frame
                    plt.imshow("Flux vidéo", frame)
                    plt.show()

                # Quitter avec 'q'
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
    finally:
        # Nettoyer les ressources
        cv2.destroyAllWindows()

# Exemple d'appel
video_url = "http://192.168.1.161:8080/stream.mjpeg?clientId=OlUVrWuu5UxpkBOu"
display_mjpeg_stream(video_url)
