#!/usr/bin/env -P /usr/bin:/usr/local/bin python3 -B
# coding: utf-8

#
#  main.py
#  image_sender
#  Created by Ingenuity i/o on 2024/11/24
#

import sys
import ingescape as igs
import cv2
import base64
import requests


last_item_id = [None, None]   # (camera, map)
current_item_id = [None, None]
pose_list = [[60,40,20],[20,40,60]]
url_image = "http://192.168.1.161:8080/stream.mjpeg?clientId=OlUVrWuu5UxpkBOu"
url_list = "list"
n = 0


def test_pose(nb_pose, current_list, tolerance= 5):
    list1 = pose_list[nb_pose]
    if len(list1) != len(current_list):
        raise ValueError("Lists must have the same length for comparison.")

    for a, b in zip(list1, current_list):
        if not (b - tolerance <= a <= b + tolerance):
            return False  

    return True      



def get_floats_from_server(url, nb_pose):
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an error for HTTP issues

        # Assuming the server returns JSON with a float list
        float_list = response.json()  # Parse JSON
        if not isinstance(float_list, list):
            raise ValueError("Response is not a list.")

        # Validate all elements are floats
        float_list = [float(x) for x in float_list]
        return float_list




    except requests.exceptions.RequestException as e:
        print(f"Error fetching data from server: {e}")
    except ValueError as ve:
        print(f"Data format error: {ve}")


def get_image_from_video(url):
     
    #ouverture du stream
    video_stream = cv2.VideoCapture(url, cv2.CAP_FFMPEG)
    if not video_stream.isOpened():
        raise ValueError("Cannot open video stream from the URL.")
    
    try: 
        while video_stream.isOpened():
            success, frame = video_stream.read()
            if not success:
                print("End of video stream or error.")
                break
            #conversion de l'image en base64
            _, buffer = cv2.imencode('.png', frame)
            base64_image = base64.b64encode(buffer).decode('utf-8')

            #appel de la fonction d'affichage d'image pour afficher l'image 
            displayimage(frame, (50,50), ratio=1, image_type=0)
    except KeyboardInterrupt:
        print("\nExiting on user request.")




def displayimage(cv_image, position = (0,0), ratio=4, image_type = 0):  #image_type 0: camera, 1: formes

        try:
            # Encodage de l'image en format JPEG
            _, buffer = cv2.imencode('.jpg', cv_image)

            image_base64 = base64.b64encode(buffer).decode('utf-8')

            height, width,  = cv_image.shape
            x, y = position
            arguments_list = (image_base64, x, y, width/ratio, height/ratio)
            igs.service_call("Whiteboard", "addImage", arguments_list, str(image_type))

            if last_item_id[image_type]:
                igs.service_call("Whiteboard", "remove", last_item_id[image_type], "")

            last_item_id[image_type] = current_item_id[image_type]

        except Exception as e:
            print(f"Error: {e}")  


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("usage: python3 main.py agent_name network_device port")
        devices = igs.net_devices_list()
        print("Please restart with one of these devices as network_device argument:")
        for device in devices:
            print(f" {device}")
        exit(0)

    igs.agent_set_name(sys.argv[1])
    igs.definition_set_class("image_sender")
    igs.log_set_console(True)
    igs.log_set_file(True, None)
    igs.set_command_line(sys.executable + " " + " ".join(sys.argv))

    igs.debug(f"Ingescape version: {igs.version()} (protocol v{igs.protocol()})")

    igs.start_with_device(sys.argv[2], int(sys.argv[3]))

    while (n < 3):
        get_image_from_video(url_image)


    # input()

    # igs.stop()

