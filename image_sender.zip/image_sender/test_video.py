import cv2
import matplotlib.pyplot as plt

def display_video_stream(url):
    """
    Récupère et affiche un flux vidéo en temps réel depuis une URL.

    Args:
        url (str): URL du flux vidéo (HTTP, HTTPS, RTSP, etc.).
    """
    # Ouvrir le flux vidéo
    video_stream = cv2.VideoCapture(url, cv2.CAP_FFMPEG)
    if not video_stream.isOpened():
        raise ValueError(f"Impossible d'ouvrir le flux vidéo depuis l'URL : {url}")

    try:
        while True:
            # Lire une frame du flux
            success, frame = video_stream.read()
            if not success:
                print("Fin du flux vidéo ou erreur.")
                break

            # Afficher la frame dans une fenêtre
            plt.imshow(frame)
            plt.show()

            # Quitter avec la touche 'q'
            if cv2.waitKey(1) & 0xFF == ord('q'):
                print("Arrêt demandé par l'utilisateur.")
                break
    finally:
        # Libérer les ressources
        video_stream.release()
        cv2.destroyAllWindows()

# Exemple d'appel
video_url = "http://192.168.186.208:8080/stream.mjpeg?clientId=B5VYIFnf29rOucTs"
display_video_stream(video_url)
