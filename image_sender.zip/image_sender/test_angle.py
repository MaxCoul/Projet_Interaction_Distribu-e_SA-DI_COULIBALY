import re

# La chaîne de caractères donnée
chaine = """
angleBetweenRightShoulderElbow = 1 
angleBetweenLeftShoulderElbow = 2 
angleBetweenRightElbowHand = 3 
angleBetweenLeftElbowHand = 4 
angleBetweenHipRightKnee = 5 
angleBetweenHipLeftKnee = 6
angleBetweenRightKneeAnkle = 7
angleBetweenLeftKneeAnkle = 10 
distanceBetweenAnkles = 9
"""

# Utilisation de re pour trouver tous les nombres dans la chaîne
nombres = re.findall(r'[-+]?\d*\.?\d+', chaine)

# Conversion des nombres en float
nombres_floats = [float(nombre) for nombre in nombres]

print(nombres_floats)
