import requests
import cv2
import numpy as np
from PIL import Image
from io import BytesIO

def display_video_stream(url):
    while True:
        # Envoyer une requête GET pour récupérer une image du flux MJPEG
        response = requests.get(url, stream=True)
        
        if response.status_code == 200:
            # Ouvrir l'image avec PIL
            img = Image.open(BytesIO(response.content))

            # Convertir l'image en format OpenCV (BGR)
            img_cv = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)

            # Afficher l'image avec OpenCV
            cv2.imshow("Flux vidéo", img_cv)

            # Quitter avec la touche 'q'
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        else:
            print(f"Erreur de récupération de l'image, code: {response.status_code}")
            break

    cv2.destroyAllWindows()

# Exemple d'appel
video_url = "http://192.168.1.161:8080/stream.mjpeg?clientId=OlUVrWuu5UxpkBOu"  # Remplacez par votre URL de flux
display_video_stream(video_url)
